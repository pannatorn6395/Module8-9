# Module8-9
<p align="center">
  <a href="https://arxiv.org/abs/1812.03506"><img src="https://thematter.co/wp-content/uploads/2022/03/%E0%B8%8A%E0%B8%B1%E0%B8%8A%E0%B8%8A%E0%B8%B2%E0%B8%95%E0%B8%B4_web-600x454.jpg" width="60%"/></a>
  <br /><em>ทำงาน ทำงาน !!!</em>
</p>
## Download Model ➡️ (https://drive.google.com/drive/folders/1-60lRZhl3UJ9nhyhqsPR0gJ_TP-rvDqX?usp=sharing)
